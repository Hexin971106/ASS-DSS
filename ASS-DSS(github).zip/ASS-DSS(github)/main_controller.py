# main_controller.py
import tkinter as tk
from tkinter import filedialog, messagebox, ttk
import threading
import os
import sys
from pathlib import Path
import logging
from datetime import datetime
import json
import shutil

# Get the directory where this file is located as the base directory for MedicalImagePipeline
BASE_DIR = Path(__file__).parent

# Dynamically import modules for other steps
try:
    from step1_processor import run_step1
    from step2_inference import run_step2
    from step3_predictor import run_step3
    # Removed step4_pvcat_processor import
except ImportError as e:
    print(f"Failed to import modules, please ensure all files are in the correct location: {e}")
    sys.exit(1)

# Setup logging
log_dir = BASE_DIR / "logs"
log_dir.mkdir(exist_ok=True)
log_filename = log_dir / f"main_controller_{datetime.now().strftime('%Y%m%d_%H%M%S')}.log"

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler(log_filename, encoding='utf-8'), # Ensure log file encoding
        logging.StreamHandler() # Console output
    ]
)

class MedicalPipelineController:
    def __init__(self, root):
        self.root = root
        self.root.title("Medical Image Processing Pipeline Controller")
        self.root.geometry("950x700")
        self.root.resizable(True, True)
        self.processing = False
        self.current_step = None
        self.create_widgets()

    def create_widgets(self):
        main_frame = ttk.Frame(self.root, padding="10")
        main_frame.pack(fill=tk.BOTH, expand=True)

        # --- Control Area ---
        control_frame = ttk.LabelFrame(main_frame, text="Path Configuration", padding="10")
        control_frame.pack(fill=tk.X, padx=5, pady=5)

        # Step 1: Raw Images
        ttk.Label(control_frame, text="1. Raw Image Folder:").grid(row=0, column=0, sticky=tk.W, pady=2)
        self.raw_img_var = tk.StringVar()
        raw_img_entry = ttk.Entry(control_frame, textvariable=self.raw_img_var, width=70)
        raw_img_entry.grid(row=0, column=1, padx=5, pady=2)
        ttk.Button(control_frame, text="Browse", command=lambda: self.browse_folder(self.raw_img_var, "Select Raw Image Folder")).grid(row=0, column=2, padx=5)

        # Step 1: TotalSegmentator Path (relative path)
        ttk.Label(control_frame, text="2. TotalSegmentator Executable:").grid(row=1, column=0, sticky=tk.W, pady=2)
        # Try to find the default TotalSegmentator path
        default_ts_exe = self.find_default_ts_exe()
        self.ts_exe_var = tk.StringVar(value=default_ts_exe)
        ts_exe_entry = ttk.Entry(control_frame, textvariable=self.ts_exe_var, width=70)
        ts_exe_entry.grid(row=1, column=1, padx=5, pady=2)
        ttk.Button(control_frame, text="Browse", command=lambda: self.browse_file(self.ts_exe_var, "Select TotalSegmentator.exe", [("Executable files", "*.exe"), ("All files", "*.*")])).grid(row=1, column=2, padx=5)

        # Step 1: Dilation Parameter
        ttk.Label(control_frame, text="3. Aorta mask dilation (mm):").grid(row=2, column=0, sticky=tk.W, pady=2)
        self.dilation_var = tk.StringVar(value="20.0")
        ttk.Entry(control_frame, textvariable=self.dilation_var, width=10).grid(row=2, column=1, sticky=tk.W, padx=5, pady=2)

        # Step 2: Model Paths (nnUNet) - Set default values
        ttk.Label(control_frame, text="4. nnUNet Model 1 (AD):").grid(row=3, column=0, sticky=tk.W, pady=2)
        self.model1_var = tk.StringVar(value=r"E:\nnunet\RESULTS_FOLDER\Dataset001_aortic\nnUNetTrainer__nnUNetPlans__3d_fullres") # Default value
        ttk.Entry(control_frame, textvariable=self.model1_var, width=70).grid(row=3, column=1, padx=5, pady=2)
        ttk.Button(control_frame, text="Browse", command=lambda: self.browse_file(self.model1_var, "Select Model 1", [("Model files", "*.pth"), ("All files", "*.*")])).grid(row=3, column=2, padx=5)

        ttk.Label(control_frame, text="5. nnUNet Model 2 (IMH):").grid(row=4, column=0, sticky=tk.W, pady=2)
        self.model2_var = tk.StringVar(value=r"E:\nnunet\RESULTS_FOLDER\Dataset002_aortic\nnUNetTrainer__nnUNetPlans__3d_fullres") # Default value
        ttk.Entry(control_frame, textvariable=self.model2_var, width=70).grid(row=4, column=1, padx=5, pady=2)
        ttk.Button(control_frame, text="Browse", command=lambda: self.browse_file(self.model2_var, "Select Model 2", [("Model files", "*.pth"), ("All files", "*.*")])).grid(row=4, column=2, padx=5)

        ttk.Label(control_frame, text="6. nnUNet Model 3 (PAU):").grid(row=5, column=0, sticky=tk.W, pady=2)
        self.model3_var = tk.StringVar(value=r"E:\nnunet\RESULTS_FOLDER\Dataset003_aortic\nnUNetTrainer__nnUNetPlans__3d_fullres") # Default value
        ttk.Entry(control_frame, textvariable=self.model3_var, width=70).grid(row=5, column=1, padx=5, pady=2)
        ttk.Button(control_frame, text="Browse", command=lambda: self.browse_file(self.model3_var, "Select Model 3", [("Model files", "*.pth"), ("All files", "*.*")])).grid(row=5, column=2, padx=5)

        # Step 3: Prediction Model Paths - Set default values
        ttk.Label(control_frame, text="7. Prediction Model 1 (AD):").grid(row=6, column=0, sticky=tk.W, pady=2)
        self.pred_model1_var = tk.StringVar(value=r"E:\test\5.权重和预处理文件\1.夹层\AD.pth") # Default value
        ttk.Entry(control_frame, textvariable=self.pred_model1_var, width=70).grid(row=6, column=1, padx=5, pady=2)
        ttk.Button(control_frame, text="Browse", command=lambda: self.browse_file(self.pred_model1_var, "Select Prediction Model 1", [("Model files", "*.pth"), ("All files", "*.*")])).grid(row=6, column=2, padx=5)

        ttk.Label(control_frame, text="8. Prediction Model 2 (IMH):").grid(row=7, column=0, sticky=tk.W, pady=2)
        self.pred_model2_var = tk.StringVar(value=r"E:\test\5.权重和预处理文件\2.壁间血肿\IMH.pth") # Default value
        ttk.Entry(control_frame, textvariable=self.pred_model2_var, width=70).grid(row=7, column=1, padx=5, pady=2)
        ttk.Button(control_frame, text="Browse", command=lambda: self.browse_file(self.pred_model2_var, "Select Prediction Model 2", [("Model files", "*.pth"), ("All files", "*.*")])).grid(row=7, column=2, padx=5)

        ttk.Label(control_frame, text="9. Prediction Model 3 (PAU):").grid(row=8, column=0, sticky=tk.W, pady=2)
        self.pred_model3_var = tk.StringVar(value=r"E:\test\5.权重和预处理文件\3.穿透性溃疡\PAU.pth") # Default value
        ttk.Entry(control_frame, textvariable=self.pred_model3_var, width=70).grid(row=8, column=1, padx=5, pady=2)
        ttk.Button(control_frame, text="Browse", command=lambda: self.browse_file(self.pred_model3_var, "Select Prediction Model 3", [("Model files", "*.pth"), ("All files", "*.*")])).grid(row=8, column=2, padx=5)

        # Step 3: N Value
        ttk.Label(control_frame, text="10. Consecutive judgment threshold (n):").grid(row=9, column=0, sticky=tk.W, pady=2)
        self.n_value_var = tk.StringVar(value="1")
        ttk.Entry(control_frame, textvariable=self.n_value_var, width=10).grid(row=9, column=1, sticky=tk.W, padx=5, pady=2)

        # Output Folder
        ttk.Label(control_frame, text="11. Output Folder:").grid(row=10, column=0, sticky=tk.W, pady=2)
        self.output_var = tk.StringVar()
        output_entry = ttk.Entry(control_frame, textvariable=self.output_var, width=70)
        output_entry.grid(row=10, column=1, padx=5, pady=2)
        ttk.Button(control_frame, text="Browse", command=lambda: self.browse_folder(self.output_var, "Select Output Folder")).grid(row=10, column=2, padx=5)

        # --- Button Area ---
        btn_frame = ttk.Frame(main_frame)
        btn_frame.pack(fill=tk.X, padx=5, pady=10)

        step_btn_frame = ttk.Frame(btn_frame)
        step_btn_frame.pack(side=tk.TOP, fill=tk.X, pady=5)

        self.step1_btn = ttk.Button(step_btn_frame, text="Run Step 1", command=lambda: self.start_step(1))
        self.step1_btn.pack(side=tk.LEFT, padx=2)
        self.step2_btn = ttk.Button(step_btn_frame, text="Run Step 2", command=lambda: self.start_step(2))
        self.step2_btn.pack(side=tk.LEFT, padx=2)
        self.step3_btn = ttk.Button(step_btn_frame, text="Run Step 3", command=lambda: self.start_step(3))
        self.step3_btn.pack(side=tk.LEFT, padx=2)
        # Removed Step 4 button

        # Complete pipeline button
        pipeline_btn_frame = ttk.Frame(btn_frame)
        pipeline_btn_frame.pack(side=tk.TOP, fill=tk.X, pady=5)

        self.run_btn = ttk.Button(pipeline_btn_frame, text="Start Full Pipeline", command=self.start_pipeline)
        self.run_btn.pack(side=tk.LEFT, padx=5)
        self.stop_btn = ttk.Button(pipeline_btn_frame, text="Stop", command=self.stop_pipeline, state=tk.DISABLED)
        self.stop_btn.pack(side=tk.LEFT, padx=5)

        # - Status and Log -
        status_frame = ttk.LabelFrame(main_frame, text="Status", padding="10")
        status_frame.pack(fill=tk.X, padx=5, pady=5)
        self.status_var = tk.StringVar(value="Ready")
        ttk.Label(status_frame, textvariable=self.status_var).pack(anchor=tk.W)

        log_frame = ttk.LabelFrame(main_frame, text="Log", padding="10")
        log_frame.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)

        self.log_text = tk.Text(log_frame, height=20, state=tk.DISABLED)
        self.log_text.pack(fill=tk.BOTH, expand=True, side=tk.LEFT)

        scrollbar = ttk.Scrollbar(log_frame, orient=tk.VERTICAL, command=self.log_text.yview)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        self.log_text.config(yscrollcommand=scrollbar.set)


    def find_default_ts_exe(self):
        """Try to find the default TotalSegmentator executable path"""
        # Can try some common installation paths
        possible_paths = [
            r"C:\Users\%USERNAME%\AppData\Local\Programs\Python\Python3x\Scripts\totalsegmentator.exe", # Need to specify Python version
            r"C:\Users\%USERNAME%\anaconda3\Scripts\totalsegmentator.exe",
            r"C:\Users\%USERNAME%\miniconda3\Scripts\totalsegmentator.exe",
            r"D:\python\Scripts\TotalSegmentator.exe", # Based on your previous path
        ]
        for path in possible_paths:
            # Expand environment variables like %USERNAME% using os.path.expanduser
            expanded_path = os.path.expanduser(path)
            if os.path.exists(expanded_path):
                return expanded_path
        # If not found, return a prompt string, user needs to set it manually
        return r"Please enter or browse to select the full path of totalsegmentator.exe"

    def browse_folder(self, var, title):
        folder = filedialog.askdirectory(title=title)
        if folder:
            var.set(folder)

    def browse_file(self, var, title, filetypes):
        file = filedialog.askopenfilename(title=title, filetypes=filetypes)
        if file:
            var.set(file)

    def validate_paths(self):
        """Validate all required paths"""
        validation_errors = []
        if not Path(self.raw_img_var.get()).exists():
            validation_errors.append("Raw image folder does not exist")
        if not Path(self.ts_exe_var.get()).exists():
            validation_errors.append("TotalSegmentator executable does not exist")
        if not self.output_var.get():
            validation_errors.append("Output folder cannot be empty")

        # Validate nnUNet model paths (now .pth file paths)
        model_paths = [
            self.model1_var.get(),
            self.model2_var.get(),
            self.model3_var.get()
        ]
        for i, path in enumerate(model_paths):
            if not Path(path).exists():
                validation_errors.append(f"nnUNet model {i+1} path does not exist (current value: {path})")

        # Validate prediction model paths
        pred_model_paths = [
            self.pred_model1_var.get(),
            self.pred_model2_var.get(),
            self.pred_model3_var.get()
        ]
        for i, path in enumerate(pred_model_paths):
            if not Path(path).exists():
                validation_errors.append(f"Prediction model {i+1} path does not exist (current value: {path})")

        # Validate output folder
        if not self.output_var.get():
            validation_errors.append("Output folder cannot be empty")

        if validation_errors:
            error_msg = "Path validation failed:\n" + "\n".join([f"- {e}" for e in validation_errors])
            messagebox.showerror("Validation Error", error_msg)
            return False
        return True

    def start_pipeline(self):
        if self.processing:
            messagebox.showwarning("Warning", "Pipeline is already running, please wait for completion or stop the current task")
            return

        # Validate all paths
        if not self.validate_paths():
            return

        self.processing = True
        self.current_step = None
        self.run_btn.config(state=tk.DISABLED)
        self.step1_btn.config(state=tk.DISABLED)
        self.step2_btn.config(state=tk.DISABLED)
        self.step3_btn.config(state=tk.DISABLED)
        # Removed step4_btn reference
        self.stop_btn.config(state=tk.NORMAL)
        self.status_var.set("Pipeline starting...")
        # Run the full pipeline in a new thread
        thread = threading.Thread(target=self.run_full_pipeline)
        thread.daemon = True
        thread.start()

    def start_step(self, step_number):
        if self.processing:
            messagebox.showwarning("Warning", "Another task is running, please wait for completion or stop the current task")
            return

        # Validate relevant paths
        if not self.validate_paths_for_step(step_number):
            return

        self.processing = True
        self.current_step = step_number
        self.disable_all_buttons()
        self.stop_btn.config(state=tk.NORMAL)
        self.status_var.set(f"Running step {step_number}...")
        # Run a single step in a new thread
        thread = threading.Thread(target=lambda: self.run_single_step(step_number))
        thread.daemon = True
        thread.start()

    def validate_paths_for_step(self, step_number):
        """Validate paths required for a specific step"""
        if step_number == 1:
            if not Path(self.raw_img_var.get()).exists():
                messagebox.showerror("Error", "Raw image folder does not exist")
                return False
            if not Path(self.ts_exe_var.get()).exists():
                messagebox.showerror("Error", "TotalSegmentator executable does not exist")
                return False
            if not self.output_var.get():
                messagebox.showerror("Error", "Output folder cannot be empty")
                return False
            return True
        elif step_number == 2:
            step1_output = os.path.join(self.output_var.get(), "step1_cleaned_images")
            if not os.path.exists(step1_output) or not os.listdir(step1_output):
                messagebox.showerror("Error", f"Step 1 output folder does not exist or is empty: {step1_output}\nPlease run step 1 first")
                return False
            model_paths = [self.model1_var.get(), self.model2_var.get(), self.model3_var.get()]
            for i, path in enumerate(model_paths):
                if not Path(path).exists():
                    messagebox.showerror("Error", f"nnUNet model {i+1} path does not exist (current value: {path})")
                    return False
            if not self.output_var.get():
                messagebox.showerror("Error", "Output folder cannot be empty")
                return False
            return True
        elif step_number == 3:
            step1_output = os.path.join(self.output_var.get(), "step1_cleaned_images")
            step2_output = os.path.join(self.output_var.get(), "step2_final_masks")
            if not os.path.exists(step1_output) or not os.listdir(step1_output):
                messagebox.showerror("Error", f"Step 1 output folder does not exist or is empty: {step1_output}\nPlease run step 1 first")
                return False
            if not os.path.exists(step2_output) or not os.listdir(step2_output):
                messagebox.showerror("Error", f"Step 2 output folder does not exist or is empty: {step2_output}\nPlease run step 2 first")
                return False
            pred_models = [self.pred_model1_var.get(), self.pred_model2_var.get(), self.pred_model3_var.get()]
            for i, path in enumerate(pred_models):
                if not Path(path).exists():
                    messagebox.showerror("Error", f"Prediction model {i+1} path does not exist (current value: {path})")
                    return False
            if not self.output_var.get():
                messagebox.showerror("Error", "Output folder cannot be empty")
                return False
            return True
        # Removed validation for step 4
        return True # Default pass for other cases (should not happen)

    def disable_all_buttons(self):
        """Disable all control buttons"""
        self.run_btn.config(state=tk.DISABLED)
        self.step1_btn.config(state=tk.DISABLED)
        self.step2_btn.config(state=tk.DISABLED)
        self.step3_btn.config(state=tk.DISABLED)
        # Removed step4_btn reference

    def enable_all_buttons(self):
        """Enable all control buttons"""
        self.run_btn.config(state=tk.NORMAL)
        self.step1_btn.config(state=tk.NORMAL)
        self.step2_btn.config(state=tk.NORMAL)
        self.step3_btn.config(state=tk.NORMAL)
        # Removed step4_btn reference

    def stop_pipeline(self):
        # Simple stop prompt
        messagebox.showinfo("Info", "Stop function: Please wait for the current step to complete or manually close the program.")

    def run_single_step(self, step_number):
        try:
            self.log(f"=== Starting Step {step_number} ===")
            if step_number == 1:
                success = self.execute_step1()
            elif step_number == 2:
                success = self.execute_step2()
            elif step_number == 3:
                success = self.execute_step3()
            # Removed step 4 execution
            else:
                success = False

            if success:
                self.status_var.set(f"Step {step_number} completed!")
                self.log(f"=== Step {step_number} completed ===")
                messagebox.showinfo("Success", f"Step {step_number} execution completed!")
            else:
                self.status_var.set(f"Step {step_number} failed")
                self.log(f"=== Step {step_number} execution failed ===")
                messagebox.showerror("Error", f"Step {step_number} execution failed!")
        except Exception as e:
            self.status_var.set(f"Step {step_number} error")
            self.log(f"Step {step_number} execution failed: {str(e)}")
            messagebox.showerror("Error", f"Step {step_number} execution failed: {str(e)}")
        finally:
            self.processing = False
            if self.current_step == step_number: # If single step execution ends
                self.current_step = None
                self.enable_all_buttons()
            if not self.current_step: # If full pipeline ends or single step execution ends
                self.stop_btn.config(state=tk.DISABLED)

    def execute_step1(self):
        raw_img_dir = self.raw_img_var.get()
        output_dir = self.output_var.get()
        ts_exe_path = self.ts_exe_var.get()
        dilation_mm = float(self.dilation_var.get())
        output_path = os.path.join(output_dir, "step1_cleaned_images")
        os.makedirs(output_path, exist_ok=True)
        return run_step1(raw_img_dir, output_path, ts_exe_path, dilation_mm=dilation_mm, position_mapping_path=os.path.join(output_dir, "position_mapping.json"))

    def execute_step2(self):
        input_dir = os.path.join(self.output_var.get(), "step1_cleaned_images")
        output_dir = os.path.join(self.output_var.get(), "step2_final_masks")
        os.makedirs(output_dir, exist_ok=True)
        model_paths = [self.model1_var.get(), self.model2_var.get(), self.model3_var.get()]
        return run_step2(input_dir, output_dir, model_paths, cleanup_intermediate=True)

    def execute_step3(self):
        img_folder = os.path.join(self.output_var.get(), "step1_cleaned_images")
        mask_folder = os.path.join(self.output_var.get(), "step2_final_masks")
        output_dir = os.path.join(self.output_var.get(), "step3_predictions")
        os.makedirs(output_dir, exist_ok=True)
        model_paths = [self.pred_model1_var.get(), self.pred_model2_var.get(), self.pred_model3_var.get()]
        n_value = int(self.n_value_var.get())
        return run_step3(img_folder, mask_folder, output_dir, model_paths, n_value=n_value, cleanup_intermediate=True)

    # Removed execute_step4 method

    def run_full_pipeline(self):
        try:
            output_dir = self.output_var.get()
            raw_img_dir = self.raw_img_var.get()
            ts_exe_path = self.ts_exe_var.get()
            dilation_mm = float(self.dilation_var.get())
            n_value = int(self.n_value_var.get())

            # 1. Check input
            if not Path(raw_img_dir).is_dir():
                raise ValueError(f"Raw image folder does not exist: {raw_img_dir}")
            if not Path(ts_exe_path).is_file():
                raise ValueError(f"TotalSegmentator executable does not exist: {ts_exe_path}")

            # Create output directory structure
            step1_output_dir = os.path.join(output_dir, "step1_cleaned_images")
            step2_output_dir = os.path.join(output_dir, "step2_final_masks")
            step3_output_dir = os.path.join(output_dir, "step3_predictions")
            # Removed step4_output_dir
            os.makedirs(step1_output_dir, exist_ok=True)
            os.makedirs(step2_output_dir, exist_ok=True)
            os.makedirs(step3_output_dir, exist_ok=True)
            # Removed os.makedirs for step4_output_dir

            # 2. Execute Step 1
            self.status_var.set("Executing Step 1: Raw Image Cleaning...")
            self.log("=== Starting Step 1: Raw Image Cleaning ===")
            step1_success = run_step1(
                raw_img_dir,
                step1_output_dir,
                ts_exe_path,
                dilation_mm=dilation_mm,
                position_mapping_path=os.path.join(output_dir, "position_mapping.json")
            )
            if not step1_success:
                raise RuntimeError("Step 1 execution failed")
            self.log("=== Step 1 completed ===")

            # 3. Execute Step 2
            self.status_var.set("Executing Step 2: nnUNet Inference...")
            self.log("=== Starting Step 2: nnUNet Inference and Label Mapping ===")
            nnunet_models = [self.model1_var.get(), self.model2_var.get(), self.model3_var.get()]
            step2_success = run_step2(
                step1_output_dir,
                step2_output_dir,
                nnunet_models,
                cleanup_intermediate=True # Clean up intermediate files
            )
            if not step2_success:
                raise RuntimeError("Step 2 execution failed")
            self.log("=== Step 2 completed ===")

            # 4. Execute Step 3
            self.status_var.set("Executing Step 3: Slice Prediction...")
            self.log("=== Starting Step 3: Slice Prediction and Result Saving ===")
            pred_models = [self.pred_model1_var.get(), self.pred_model2_var.get(), self.pred_model3_var.get()]
            step3_success = run_step3(
                step1_output_dir,
                step2_output_dir,
                step3_output_dir,
                pred_models,
                n_value=n_value,
                cleanup_intermediate=True # Clean up intermediate files
            )
            if not step3_success:
                raise RuntimeError("Step 3 execution failed")
            self.log("=== Step 3 completed ===")

            # Removed Step 4 execution

            # 5. Complete
            self.status_var.set("Pipeline completed!")
            self.log("=== Full Pipeline Execution Successful ===")
            messagebox.showinfo("Success", "Full pipeline execution completed!")
            self.log("Output results saved in: " + output_dir)

        except Exception as e:
            self.status_var.set("Pipeline failed")
            self.log(f"=== Full Pipeline Execution Failed: {str(e)} ===")
            messagebox.showerror("Error", f"Pipeline execution failed: {str(e)}")
        finally:
            self.processing = False
            self.enable_all_buttons()
            self.stop_btn.config(state=tk.DISABLED)

    def log(self, message):
        self.log_text.config(state=tk.NORMAL)
        self.log_text.insert(tk.END, message + "\n")
        self.log_text.see(tk.END)
        self.log_text.config(state=tk.DISABLED)
        self.root.update_idletasks() # Refresh interface

if __name__ == "__main__":
    root = tk.Tk()
    app = MedicalPipelineController(root)
    root.mainloop()