# step3_predictor.py
import os
import sys
import numpy as np
import torch
import torch.nn as nn
from torchvision import transforms, models
from PIL import Image
import matplotlib.pyplot as plt
import logging
import pandas as pd
import time
import nibabel as nib
import re
import shutil
from pathlib import Path
from datetime import datetime
import json

# 确保中文显示正常
plt.rcParams["font.family"] = ["SimHei", "WenQuanYi Micro Hei", "Heiti TC", "Arial Unicode MS"]
plt.rcParams["axes.unicode_minus"] = False

# 设置日志
log_dir = Path(__file__).parent / "logs"
log_dir.mkdir(exist_ok=True, parents=True)
log_filename = log_dir / f"step3_predictor_{datetime.now().strftime('%Y%m%d_%H%M%S')}.log"
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler(log_filename),
        logging.StreamHandler()
    ]
)

def get_image_transform():
    """获取图像预处理转换"""
    return transforms.Compose([
        transforms.Resize((224, 224)),
        transforms.ToTensor(),
        transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])
    ])

def load_and_preprocess_image(image_path, transform):
    """加载并预处理图像"""
    image = Image.open(image_path).convert('RGB')
    original_image = image.copy()
    image_tensor = transform(image).unsqueeze(0)
    return original_image, image_tensor

def init_model(num_classes=2):
    """初始化ResNet18模型"""
    model = models.resnet18(weights=models.ResNet18_Weights.IMAGENET1K_V1)
    for param in list(model.parameters())[:-10]:
        param.requires_grad = False
    num_ftrs = model.fc.in_features
    model.fc = nn.Linear(num_ftrs, num_classes)
    return model

def get_base_filename(filename):
    """从文件名中提取基础名称，移除所有后缀和末尾数字"""
    base = filename
    while base.rfind('.') != -1:
        base = os.path.splitext(base)[0]
    pattern = r'_\d+$'
    base = re.sub(pattern, '', base)
    return base

class NiiMultiModelPipeline:
    def __init__(self, img_folder, mask_folder, output_folder, model_paths, n_value=1):
        self.img_folder = img_folder
        self.mask_folder = mask_folder
        self.output_folder = output_folder
        self.model_paths = model_paths  # [path1, path2, path3]
        self.n_value = n_value
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        self.transform = get_image_transform()
        self.models = [None, None, None]
        self.model_results = {}
        self.heatmap_log = []
        self.class_names = ["类别0", "类别1"]
        # 存储所有标签文件夹路径，用于清理
        self.label_folders = []

    def log(self, message):
        """记录日志信息"""
        logging.info(message)

    def _load_models(self):
        """加载所有预测模型"""
        self.log("开始加载模型...")
        total_models = len(self.model_paths)
        for idx, model_path in enumerate(self.model_paths):
            if not model_path or not os.path.exists(model_path):
                self.log(f"模型{idx+1}路径无效或未选择: {model_path}")
                continue
            self.log(f"加载模型{idx+1}: {os.path.basename(model_path)}")
            try:
                model = init_model(num_classes=2)
                model = model.to(self.device)
                checkpoint = torch.load(model_path, map_location=self.device)
                model.load_state_dict(checkpoint['model_state_dict'])
                model.eval()
                self.models[idx] = model
                self.log(f"模型{idx+1}加载成功: {os.path.basename(model_path)}")
            except Exception as e:
                self.log(f"模型{idx+1}加载失败: {str(e)}")
                self.models[idx] = None  # 标记加载失败

        loaded_count = sum(1 for m in self.models if m is not None)
        self.log(f"模型加载完成，成功加载 {loaded_count}/{total_models} 个模型")

    def _process_nii_files(self):
        """处理NII文件，生成切片图像"""
        self.log("开始处理Nii文件...")
        img_files = [f for f in os.listdir(self.img_folder) if f.endswith(('.nii', '.nii.gz'))]
        img_files.sort()
        total_imgs = len(img_files)

        img_base_map = {}
        for img_file in img_files:
            base_name = get_base_filename(img_file)
            if base_name not in img_base_map:
                img_base_map[base_name] = []
            img_base_map[base_name].append(img_file)

        mask_files = [f for f in os.listdir(self.mask_folder) if f.endswith(('.nii', '.nii.gz'))]
        mask_base_map = {}
        for mask_file in mask_files:
            base_name = get_base_filename(mask_file)
            if base_name not in mask_base_map:
                mask_base_map[base_name] = []
            mask_base_map[base_name].append(mask_file)

        self.log(f"找到 {total_imgs} 个原图文件，开始基于基础名匹配Mask...")
        self.log(f"原图基础名数量: {len(img_base_map)}, Mask基础名数量: {len(mask_base_map)}")

        # 创建标签文件夹
        label_folders = []
        for label in range(1, 18):
            label_folder = os.path.join(self.output_folder, f"标签_{label}")
            os.makedirs(label_folder, exist_ok=True)
            label_folders.append(label_folder)

        # 存储所有切片文件夹路径，用于后续清理
        self.label_folders = label_folders

        processed_files = []
        matched_base_names = set(img_base_map.keys()) & set(mask_base_map.keys())
        unmatched_img_bases = set(img_base_map.keys()) - set(mask_base_map.keys())

        for base in unmatched_img_bases:
            self.log(f"未找到匹配的Mask：原图基础名 '{base}'（对应文件：{img_base_map[base]}）")

        total_matched = len(matched_base_names)
        self.log(f"找到 {total_matched} 个匹配的文件对")

        for base_idx, base_name in enumerate(matched_base_names):
            img_file_list = img_base_map[base_name]
            mask_file_list = mask_base_map[base_name]
            img_filename = img_file_list[0]
            mask_filename = mask_file_list[0]
            self.log(f"处理 {base_idx+1}/{total_matched}: '{base_name}' (原图: {img_filename}, Mask: {mask_filename})")

            img_path = os.path.join(self.img_folder, img_filename)
            mask_path = os.path.join(self.mask_folder, mask_filename)

            try:
                img_nii = nib.load(img_path)
                mask_nii = nib.load(mask_path)
                img_data = img_nii.get_fdata()
                mask_data = mask_nii.get_fdata()

                if img_data.shape != mask_data.shape:
                    self.log(f"跳过基础名 '{base_name}'：图像和Mask形状不匹配（{img_data.shape} vs {mask_data.shape}）")
                    continue
            except Exception as e:
                self.log(f"跳过基础名 '{base_name}'：读取文件出错 - {str(e)}")
                continue

            file_name = base_name
            processed_files.append(file_name)

            # 为每个文件创建子文件夹
            file_folders = []
            for label in range(17):
                file_folder = os.path.join(label_folders[label], file_name)
                os.makedirs(file_folder, exist_ok=True)
                file_folders.append(file_folder)
                # 记录切片文件夹路径
                # if file_folder not in self.slice_folders: # 这行不再需要，因为整个文件夹会被删除
                #     self.slice_folders.append(file_folder)

            # 处理每个标签
            for label in range(1, 18):
                label_idx = label - 1
                label_mask = (mask_data == label).astype(np.float32)
                if not np.any(label_mask):
                    continue

                masked_img = img_data * label_mask
                non_zero = np.nonzero(masked_img)
                if len(non_zero[0]) == 0:
                    continue

                min_x, max_x = np.min(non_zero[0]), np.max(non_zero[0])
                min_y, max_y = np.min(non_zero[1]), np.max(non_zero[1])
                min_z, max_z = np.min(non_zero[2]), np.max(non_zero[2])

                cropped_img = masked_img[min_x:max_x+1, min_y:max_y+1, min_z:max_z+1]
                slices_count = cropped_img.shape[2]
                processed_slices = 0
                for slice_idx in range(slices_count):
                    slice_data = cropped_img[:, :, slice_idx]
                    if np.min(slice_data) < 0:
                        slice_data = slice_data - np.min(slice_data)
                    if np.max(slice_data) > 0:
                        slice_data = (slice_data / np.max(slice_data) * 255).astype(np.uint8)
                    else:
                        slice_data = np.zeros_like(slice_data, dtype=np.uint8)

                    output_path = os.path.join(file_folders[label_idx], f"slice_{slice_idx:04d}.png")
                    img = Image.fromarray(slice_data)
                    img.save(output_path)
                    processed_slices += 1

                if processed_slices > 0:
                    self.log(f"  标签{label}: 生成 {processed_slices} 个切片")

            self.log(f"完成处理基础名 '{base_name}'")

        self.log(f"Nii文件处理完成，共处理 {len(processed_files)} 个基础名")
        return processed_files

    def _has_consecutive_ones(self, predictions, n):
        """检查是否有连续n个1"""
        count = 0
        for pred in predictions:
            if pred == 1:
                count += 1
                if count >= n:
                    return 1
            else:
                count = 0
        return 0

    def _predict_with_models(self, total_files, total_models):
        """使用模型进行预测"""
        self.log("开始对切片进行预测...")
        self.model_results = {}

        # 确定哪些模型成功加载
        loaded_model_info = [(i, f"模型{i+1}") for i, model in enumerate(self.models) if model is not None]
        total_loaded = len(loaded_model_info)

        if total_loaded == 0:
            self.log("没有成功加载的模型，跳过预测")
            return

        # 初始化结果字典
        for _, model_name in loaded_model_info:
            self.model_results[model_name] = {}

        # 处理每个标签
        for label in range(1, 18):
            label_folder = os.path.join(self.output_folder, f"标签_{label}")
            if not os.path.exists(label_folder):
                self.log(f"标签{label}文件夹不存在，跳过")
                continue

            file_folders = [f for f in os.listdir(label_folder) if os.path.isdir(os.path.join(label_folder, f))]
            file_folders.sort()

            self.log(f"处理标签{label}/17，共 {len(file_folders)} 个文件")

            for file_idx, file_name in enumerate(file_folders):
                # 初始化文件结果
                for _, model_name in loaded_model_info:
                    if file_name not in self.model_results[model_name]:
                        self.model_results[model_name][file_name] = {}

                file_folder = os.path.join(label_folder, file_name)
                png_files = sorted([f for f in os.listdir(file_folder) if f.lower().endswith('.png')])
                if not png_files:
                    for _, model_name in loaded_model_info:
                        self.model_results[model_name][file_name][f"标签{label}"] = 0
                    self.log(f"  标签{label} - {file_name}: 无切片，结果为0")
                    continue

                # 对每个成功加载的模型进行预测
                for model_idx, model_name in loaded_model_info:
                    model = self.models[model_idx]
                    predictions = []
                    for img_file in png_files:
                        img_path = os.path.join(file_folder, img_file)
                        try:
                            _, image_tensor = load_and_preprocess_image(img_path, self.transform)
                            image_tensor = image_tensor.to(self.device)
                            with torch.no_grad():
                                outputs = model(image_tensor)
                                _, predicted = torch.max(outputs.data, 1)
                                # 注意这里的反转逻辑：原代码中1表示正常，0表示异常
                                # 这里我们反转，让1表示异常（阳性），0表示正常（阴性）
                                reversed_pred = 1 - predicted.item()
                                predictions.append(reversed_pred)
                        except Exception as e:
                            self.log(f"    预测切片 {img_file} 时出错: {str(e)}")
                            predictions.append(0)  # 出错时默认为0（阴性）

                    # 应用连续判断阈值
                    final_result = self._has_consecutive_ones(predictions, self.n_value)
                    self.model_results[model_name][file_name][f"标签{label}"] = final_result

                self.log(f"  标签{label} - {file_name}: {len(png_files)}个切片，处理完成")

        self.log("预测完成")

    def _save_results(self, output_excel_path):
        """保存预测结果"""
        if not self.model_results or all(not results for results in self.model_results.values()):
            self.log("没有结果数据可保存")
            return

        try:
            # 创建结果目录
            os.makedirs(os.path.dirname(output_excel_path), exist_ok=True)

            with pd.ExcelWriter(output_excel_path, engine='openpyxl') as writer:
                for model_name, results in self.model_results.items():
                    data = []
                    for file_name in sorted(results.keys()):
                        row = {"文件名": file_name}
                        row.update(results[file_name])
                        data.append(row)

                    results_df = pd.DataFrame(data)

                    # 确保所有标签列都存在
                    for label in range(1, 18):
                        if f"标签{label}" not in results_df.columns:
                            results_df[f"标签{label}"] = 0

                    # 按正确顺序排列列
                    columns = ["文件名"] + [f"标签{i}" for i in range(1, 18)]
                    results_df = results_df[columns]

                    results_df.to_excel(writer, sheet_name=model_name, index=False)

            self.log(f"结果表格保存至：{output_excel_path}")
        except Exception as e:
            self.log(f"保存结果失败：{str(e)}")

    def cleanup_intermediate_files(self):
        """清理中间切片文件夹（整个标签文件夹）"""
        try:
            self.log("=== 开始清理中间切片文件夹 ===")
            # 删除所有标签文件夹
            cleaned_count = 0
            for folder in self.label_folders: # 遍历的是整个标签文件夹
                if os.path.exists(folder):
                    try:
                        shutil.rmtree(folder) # 删除整个文件夹及其内容
                        cleaned_count += 1
                        self.log(f"已删除标签文件夹: {folder}")
                    except Exception as e:
                        self.log(f"删除文件夹失败 {folder}: {str(e)}")
            self.log(f"已清理 {cleaned_count} 个标签文件夹")
        except Exception as e:
            self.log(f"清理中间文件夹时出错: {str(e)}")


    def run_pipeline(self, cleanup_intermediate=False):
        """
        执行完整的预测流程
        cleanup_intermediate: 是否清理中间文件
        """
        self.log("=== 开始步骤3：切片预测与结果保存 ===")

        # 1. 加载模型
        self._load_models()
        loaded_models = [m for m in self.models if m is not None]
        if not loaded_models:
            self.log("没有模型加载成功，无法进行预测")
            return False

        # 2. 处理NII文件
        nii_files = self._process_nii_files()
        if not nii_files:
            self.log("没有找到有效的.nii.gz文件对进行处理")
            return False

        # 3. 预测
        self._predict_with_models(len(nii_files), len(loaded_models))

        # 4. 保存结果
        output_excel_path = os.path.join(self.output_folder, "prediction_results.xlsx")
        self._save_results(output_excel_path)

        # 5. 清理中间文件
        if cleanup_intermediate:
            self.log("=== 清理中间切片文件夹 ===")
            self.cleanup_intermediate_files() # 调用修改后的方法

        self.log(f"=== 步骤3完成 ===")
        self.log(f"共处理 {len(nii_files)} 个文件，使用 {len(loaded_models)} 个模型")
        self.log(f"结果表格已保存至: {output_excel_path}")
        return True

def run_step3(img_folder, mask_folder, output_folder, model_paths, n_value=1, cleanup_intermediate=False):
    """
    执行步骤3的完整流程
    cleanup_intermediate: 是否清理中间文件
    """
    pipeline = NiiMultiModelPipeline(img_folder, mask_folder, output_folder, model_paths, n_value)
    return pipeline.run_pipeline(cleanup_intermediate)

if __name__ == "__main__":
    # 示例调用 (请替换为实际路径)
    base_dir = Path(__file__).parent
    models = [
        str(base_dir / "AD.pth"),
        str(base_dir / "IMH.pth"),
        str(base_dir / "PAU.pth")
    ]
    run_step3(
        img_folder=str(base_dir / "step1_cleaned_images"),
        mask_folder=str(base_dir / "step2_final_masks"),
        output_folder=str(base_dir / "step3_predictions"),
        model_paths=models,
        n_value=1,
        cleanup_intermediate=True
    )