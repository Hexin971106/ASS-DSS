# step1_processor.py
import os
import logging
import subprocess
import shutil
import tempfile
import SimpleITK as sitk
import numpy as np
import json
from pathlib import Path
from datetime import datetime
import re
import gzip

# 设置日志
log_dir = Path(__file__).parent / "logs"
log_dir.mkdir(exist_ok=True, parents=True)
log_filename = log_dir / f"step1_processor_{datetime.now().strftime('%Y%m%d_%H%M%S')}.log"
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler(log_filename),
        logging.StreamHandler()
    ]
)

def convert_to_compatible_format(input_path: Path) -> Path:
    """转换文件格式为TotalSegmentator兼容格式"""
    try:
        image = sitk.ReadImage(str(input_path))
        temp_dir = Path(tempfile.mkdtemp())
        
        if input_path.suffix == ".gz":
            temp_nii = temp_dir / f"{input_path.stem}"
            sitk.WriteImage(image, str(temp_nii))
            temp_gz = temp_dir / f"{input_path.name}"
            with open(temp_nii, 'rb') as f_in, gzip.open(temp_gz, 'wb') as f_out:
                f_out.writelines(f_in)
            sitk.ReadImage(str(temp_gz))
            logging.info(f"文件 {input_path.name} 已转换为标准gzip格式")
            return temp_gz
        else:
            return input_path
    except Exception as e:
        logging.warning(f"重新压缩失败，尝试转为未压缩.nii：{str(e)}")
        temp_dir = Path(tempfile.mkdtemp())
        temp_nii = temp_dir / f"{input_path.stem.replace('.nii', '')}.nii"
        sitk.WriteImage(image, str(temp_nii))
        logging.info(f"文件 {input_path.name} 已转换为未压缩.nii格式")
        return temp_nii

def is_image_valid(file_path):
    """验证图像文件是否有效"""
    try:
        sitk.ReadImage(str(file_path))
        return True
    except sitk.sitkIOError as e:
        logging.error(f"医学影像文件 {file_path} 损坏或无效: {str(e)}")
        return False
    except Exception as e:
        logging.warning(f"验证文件 {file_path} 时出现意外: {str(e)}")
        return True

def is_mask_already_exist(output_dir: str, original_filename: str) -> bool:
    """检查mask是否已存在"""
    output_path = Path(output_dir)
    if original_filename.lower().endswith(".nii.gz"):
        base_name = original_filename[:-7]
    elif original_filename.lower().endswith(".nii"):
        base_name = original_filename[:-4]
    else:
        base_name = original_filename
        
    mask_path = output_path / f"{base_name}_aorta.nii.gz"
    return mask_path.exists()

def batch_segment_aorta(input_dir: str, output_dir: str, exe_path: str, device: str = "gpu", skip_verify: bool = False):
    """批量分割主动脉"""
    input_path = Path(input_dir)
    output_path = Path(output_dir)
    
    if not input_path.is_dir():
        logging.error(f"输入文件夹不存在：{input_dir}")
        return 0, 1  # processed, failed
        
    output_path.mkdir(parents=True, exist_ok=True)
    
    nifti_extensions = (".nii.gz", ".nii")
    input_files = [f for f in input_path.iterdir() if f.is_file() and f.name.lower().endswith(nifti_extensions)]
    total_files = len(input_files)
    
    if total_files == 0:
        logging.warning("输入文件夹中未找到 .nii 或 .nii.gz 格式的图像文件")
        return 0, 0
        
    processed_count = 0
    failed_count = 0
    failed_files = []
    temp_files = []
    
    for i, img_file in enumerate(input_files):
        img_filename = img_file.name
        if img_filename.lower().endswith(".nii.gz"):
            base_name = img_filename[:-7]
        else:
            base_name = img_filename[:-4]
            
        logging.info(f"处理第 {i+1}/{total_files} 个文件: {img_filename}")
        
        # 检查是否已存在
        if is_mask_already_exist(output_dir, img_filename):
            logging.info(f"文件 {img_filename} 已存在，跳过处理")
            processed_count += 1
            continue
            
        # 验证文件
        if not skip_verify and not is_image_valid(img_file):
            logging.error(f"文件 {img_filename} 损坏，跳过处理")
            failed_count += 1
            failed_files.append(img_filename)
            continue
            
        # 转换格式
        try:
            compatible_file = convert_to_compatible_format(img_file)
            temp_files.append(compatible_file.parent)
        except Exception as e:
            logging.error(f"文件 {img_filename} 格式转换失败：{str(e)}")
            failed_count += 1
            failed_files.append(img_filename)
            continue
            
        # 创建临时输出目录
        temp_out_dir = output_path / f"temp_{base_name}"
        temp_out_dir.mkdir(exist_ok=True)
        
        # 运行TotalSegmentator
        cmd = [exe_path, "-i", str(compatible_file), "-o", str(temp_out_dir), "-d", device, "-s", "--roi_subset", "aorta"]
        
        try:
            logging.info(f"开始分割文件：{img_filename}（使用转换后的格式）")
            result = subprocess.run(cmd, check=True, capture_output=True, text=True, timeout=3600)
            logging.debug(f"分割命令输出：{result.stdout}")
            
            temp_mask_path = temp_out_dir / "aorta.nii.gz"
            final_mask_path = output_path / f"{base_name}_aorta.nii.gz"
            
            if not temp_mask_path.exists():
                raise FileNotFoundError("TotalSegmentator未生成主动脉掩码文件")
                
            temp_mask_path.replace(final_mask_path)
            logging.info(f"成功分割 {img_filename}，结果保存至：{final_mask_path}")
            processed_count += 1
            
        except (subprocess.CalledProcessError, subprocess.TimeoutExpired, Exception) as e:
            logging.error(f"处理文件 {img_filename} 失败：{str(e)}")
            if isinstance(e, subprocess.CalledProcessError):
                logging.error(f"分割命令错误输出：{e.stderr}")
            failed_count += 1
            failed_files.append(img_filename)
            
        finally:
            # 清理临时目录
            if temp_out_dir.exists():
                try:
                    shutil.rmtree(temp_out_dir)
                except Exception as e:
                    logging.warning(f"清理临时目录 {temp_out_dir} 失败：{str(e)}")
                    
    # 清理临时文件
    for temp_dir in temp_files:
        try:
            shutil.rmtree(temp_dir)
        except Exception as e:
            logging.warning(f"清理临时文件目录 {temp_dir} 失败：{str(e)}")
            
    report_msg = f"分割阶段完成！总文件数：{total_files}，成功分割：{processed_count} 个，分割失败：{failed_count} 个"
    if failed_files:
        report_msg += f"，失败文件列表：{', '.join(failed_files)}"
    logging.info(report_msg)
    
    return processed_count, failed_count

def extract_numbers(filename):
    """从文件名中提取数字"""
    numbers = re.findall(r'\d+', filename)
    return ''.join(numbers)

def get_matching_files(input_dir, mask_dir):
    """获取匹配的输入文件和mask文件"""
    input_files = [f for f in os.listdir(input_dir) if f.endswith('.nii.gz')]
    mask_files = [f for f in os.listdir(mask_dir) if f.endswith('_aorta.nii.gz')]
    
    input_map = {extract_numbers(f): f for f in input_files}
    mask_map = {extract_numbers(f): f for f in mask_files}
    
    matched_pairs = []
    for num_str in input_map:
        if num_str in mask_map:
            matched_pairs.append((input_map[num_str], mask_map[num_str]))
            
    unmatched_input = [f for f in input_files if extract_numbers(f) not in mask_map]
    unmatched_mask = [f for f in mask_files if extract_numbers(f) not in input_map]
    
    return matched_pairs, unmatched_input, unmatched_mask

def get_bounding_box(binary_image):
    """获取二值图像的边界框"""
    arr = sitk.GetArrayFromImage(binary_image)
    coords = np.where(arr != 0)
    
    if coords[0].size == 0:
        raise ValueError("Mask 为空，无法计算 bounding box")
        
    min_z, max_z = coords[0].min(), coords[0].max()
    min_y, max_y = coords[1].min(), coords[1].max()
    min_x, max_x = coords[2].min(), coords[2].max()
    
    return (min_z, max_z, min_y, max_y, min_x, max_x)

def crop_image_by_bbox(image, bbox):
    """根据边界框裁剪图像"""
    min_z, max_z, min_y, max_y, min_x, max_x = bbox
    arr = sitk.GetArrayFromImage(image)
    cropped_arr = arr[min_z:max_z+1, min_y:max_y+1, min_x:max_x+1]
    
    cropped_image = sitk.GetImageFromArray(cropped_arr)
    cropped_image.SetSpacing(image.GetSpacing())
    cropped_image.SetDirection(image.GetDirection())
    
    old_origin = image.GetOrigin()
    old_spacing = image.GetSpacing()
    
    new_origin_x = old_origin[0] + min_x * old_spacing[0]
    new_origin_y = old_origin[1] + min_y * old_spacing[1]
    new_origin_z = old_origin[2] + min_z * old_spacing[2]
    
    cropped_image.SetOrigin([new_origin_x, new_origin_y, new_origin_z])
    
    return cropped_image

def save_position_mapping(position_info, json_path):
    """保存位置映射信息到JSON文件"""
    try:
        if os.path.exists(json_path):
            with open(json_path, 'r', encoding='utf-8') as f:
                existing_data = json.load(f)
        else:
            existing_data = []
            
        existing_data.append(position_info)
        
        with open(json_path, 'w', encoding='utf-8') as f:
            json.dump(existing_data, f, indent=2, ensure_ascii=False)
            
    except Exception as e:
        logging.error(f"保存位置映射信息失败: {str(e)}")

def process_image(input_path, mask_path, output_path, dilation_mm, input_file, position_mapping_path=None):
    """处理单个图像：膨胀、裁剪、保存位置映射"""
    input_image = sitk.ReadImage(input_path)
    mask_image = sitk.ReadImage(mask_path)
    
    if input_image.GetSize() != mask_image.GetSize():
        raise ValueError(f"输入影像和mask大小不一致: {input_image.GetSize()} vs {mask_image.GetSize()}")
        
    # 处理mask
    mask_array = sitk.GetArrayFromImage(mask_image)
    mask_array = (mask_array > 0).astype(np.uint8)
    original_mask = sitk.GetImageFromArray(mask_array)
    original_mask.CopyInformation(input_image)
    
    # 膨胀
    spacing = mask_image.GetSpacing()
    dilation_radius = int(np.ceil(dilation_mm / spacing[0]))
    
    if dilation_radius > 0:
        dilate_filter = sitk.BinaryDilateImageFilter()
        dilate_filter.SetKernelRadius(dilation_radius)
        dilate_filter.SetKernelType(sitk.sitkBall)
        dilated_mask = dilate_filter.Execute(original_mask)
    else:
        dilated_mask = original_mask
        
    # 获取边界框
    bbox = get_bounding_box(dilated_mask)
    min_z, max_z, min_y, max_y, min_x, max_x = bbox
    
    logging.info(f"  膨胀后Mask Bounding Box (z, y, x): z({min_z}, {max_z}), y({min_y}, {max_y}), x({min_x}, {max_x})")
    
    # 裁剪
    cropped_input = crop_image_by_bbox(input_image, bbox)
    cropped_dilated_mask = crop_image_by_bbox(dilated_mask, bbox)
    
    # 应用mask
    input_array = sitk.GetArrayFromImage(cropped_input)
    mask_array = sitk.GetArrayFromImage(cropped_dilated_mask)
    processed_array = input_array * mask_array
    
    processed_image = sitk.GetImageFromArray(processed_array)
    processed_image.CopyInformation(cropped_input)
    
    # 保存处理后的图像
    sitk.WriteImage(processed_image, output_path)
    
    # 保存位置映射信息
    if position_mapping_path:
        original_size = input_image.GetSize()
        cropped_size = cropped_input.GetSize()
        original_origin = input_image.GetOrigin()
        original_spacing = input_image.GetSpacing()
        cropped_origin = cropped_input.GetOrigin()
        
        position_info = {
            'filename': input_file,
            'original_size': list(original_size),
            'cropped_size': list(cropped_size),
            'original_origin': list(original_origin),
            'cropped_origin': list(cropped_origin),
            'original_spacing': list(original_spacing),
            'bbox': {
                'min_x': int(min_x), 'max_x': int(max_x),
                'min_y': int(min_y), 'max_y': int(max_y), 
                'min_z': int(min_z), 'max_z': int(max_z)
            },
            'dilation_mm_used': float(dilation_mm)
        }
        
        save_position_mapping(position_info, position_mapping_path)
        logging.info(f"  位置映射信息已保存: {position_info}")

def post_process_images(input_dir, mask_dir, output_dir, dilation_mm, position_mapping_path=None):
    """后处理图像：膨胀、裁剪、保存映射"""
    if not all([input_dir, mask_dir, output_dir]):
        logging.error("路径不能为空")
        return 0, 0
        
    try:
        dilation_mm = float(dilation_mm)
        if dilation_mm < 0:
            raise ValueError("膨胀尺寸不能为负数")
    except:
        logging.error("无效的膨胀尺寸")
        return 0, 0
        
    os.makedirs(output_dir, exist_ok=True)
    
    matched_pairs, unmatched_input, unmatched_mask = get_matching_files(input_dir, mask_dir)
    
    if unmatched_input:
        logging.info(f"未找到匹配mask的输入文件 ({len(unmatched_input)}个): {', '.join(unmatched_input)}")
    if unmatched_mask:
        logging.info(f"未找到匹配输入的mask文件 ({len(unmatched_mask)}个): {', '.join(unmatched_mask)}")
        
    if not matched_pairs:
        logging.warning("未找到任何匹配的文件对，无法进行处理")
        return 0, len(unmatched_input) + len(unmatched_mask)
        
    logging.info(f"找到 {len(matched_pairs)} 对匹配的文件，开始后处理...")
    logging.info(f"使用的参数：膨胀尺寸={dilation_mm}mm")
    
    total = len(matched_pairs)
    success_count = 0
    
    for i, (input_file, mask_file) in enumerate(matched_pairs):
        try:
            logging.info(f"处理 {input_file} (匹配 {mask_file})")
            input_path = os.path.join(input_dir, input_file)
            mask_path = os.path.join(mask_dir, mask_file)
            output_path = os.path.join(output_dir, input_file)
            
            process_image(input_path, mask_path, output_path, dilation_mm, input_file, position_mapping_path)
            success_count += 1
            logging.info(f"  处理成功")
        except Exception as e:
            error_msg = f"  处理失败: {str(e)}"
            logging.error(error_msg)
            
    logging.info(f"后处理完成。成功: {success_count}/{total}")
    if position_mapping_path:
        logging.info(f"位置映射信息已保存到: {position_mapping_path}")
        
    return success_count, total - success_count

def run_step1(input_dir, output_dir, exe_path, dilation_mm=20.0, device="gpu", skip_verify=False, position_mapping_path=None):
    """
    执行步骤1的完整流程：分割 -> 后处理
    """
    logging.info("=== 开始步骤1：原图清洗 (分割 + 后处理) ===")
    
    # 创建临时分割目录
    temp_segmentation_dir = Path(output_dir) / "temp_masks_step1"
    temp_segmentation_dir.mkdir(parents=True, exist_ok=True)
    
    # 1. 分割主动脉
    seg_success, seg_failed = batch_segment_aorta(input_dir, str(temp_segmentation_dir), exe_path, device, skip_verify)
    
    if seg_success == 0:
        logging.error("步骤1分割阶段没有成功处理任何文件，终止后续处理。")
        return False
        
    # 2. 后处理
    pp_success, pp_failed = post_process_images(
        input_dir, 
        str(temp_segmentation_dir), 
        output_dir, 
        dilation_mm, 
        position_mapping_path
    )
    
    logging.info(f"=== 步骤1完成 ===")
    logging.info(f"分割: 成功 {seg_success}, 失败 {seg_failed}")
    logging.info(f"后处理: 成功 {pp_success}, 失败 {pp_failed}")
    
    # 3. 清理临时分割结果
    try:
        if temp_segmentation_dir.exists():
            shutil.rmtree(temp_segmentation_dir)
            logging.info(f"步骤1临时分割结果已清理: {temp_segmentation_dir}")
    except Exception as e:
        logging.warning(f"清理步骤1临时分割结果失败: {str(e)}")
        
    return True