# step2_inference.py
import os
import logging
import subprocess
import re
import sys
from datetime import datetime
import shutil
import nibabel as nib
import numpy as np
import SimpleITK as sitk
from pathlib import Path

# 设置日志
log_dir = Path(__file__).parent / "logs"
log_dir.mkdir(exist_ok=True, parents=True)
log_filename = log_dir / f"step2_inference_{datetime.now().strftime('%Y%m%d_%H%M%S')}.log"
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler(log_filename),
        logging.StreamHandler()
    ]
)

class NnUNetInferencePipeline:
    def __init__(self, input_folder, output_folder, model_paths, temp_dir=None):
        self.input_folder = input_folder
        self.output_folder = output_folder
        self.model_paths = model_paths  # 应该是包含三个路径的列表
        self.temp_dir = temp_dir or os.path.join(os.getcwd(), "temp_inference")
        
        # 标签映射表
        self.weight1_mapping = {
            1: 1, 2: 3, 3: 5, 4: 7, 5: 8, 6: 9, 7: 10, 8: 12, 9: 14, 10: 17
        }
        self.weight3_mapping = {
            2: 2, 3: 4, 4: 6, 5: 11, 6: 13, 7: 15, 8: 16
        }
        
    def log_message(self, message):
        logging.info(message)
        
    def parse_model_folder_path(self, folder_path):
        """解析模型文件夹路径获取必要信息"""
        try:
            config_dir = os.path.basename(folder_path)
            if "__" not in config_dir or len(config_dir.split("__")) < 3:
                self.log_message(f"解析失败: 配置文件夹名格式错误 - {config_dir}")
                return None
                
            parts = config_dir.split("__")
            config = parts[-1]
            dataset_dir = os.path.basename(os.path.dirname(folder_path))
            
            if not dataset_dir.startswith("Dataset"):
                self.log_message(f"解析失败: 数据集文件夹名不以'Dataset'开头 - {dataset_dir}")
                return None
                
            match = re.match(r"Dataset(\d+)", dataset_dir)
            if not match:
                self.log_message(f"解析失败: 数据集文件夹名格式错误 - {dataset_dir}")
                return None
                
            dataset_id = match.group(1)
            
            # 获取第一个fold
            fold_dirs = [d for d in os.listdir(folder_path) if re.match(r"fold_\d+", d)]
            if not fold_dirs:
                self.log_message(f"解析失败: 未找到fold文件夹 - {folder_path}")
                return None
                
            first_fold = fold_dirs[0].split("_")[-1]
            fold_path = os.path.join(folder_path, f"fold_{first_fold}")
            
            # 查找checkpoint
            checkpoint_options = ["checkpoint_best.pth", "checkpoint_final.pth"]
            checkpoint_found = None
            for cp_name in checkpoint_options:
                cp_path = os.path.join(fold_path, cp_name)
                if os.path.exists(cp_path):
                    checkpoint_found = cp_name
                    break
                    
            if not checkpoint_found:
                self.log_message(f"解析失败: 未找到checkpoint文件 - {fold_path}")
                return None
                
            return {
                'path': folder_path,
                'dataset_id': dataset_id,
                'config': config,
                'fold': first_fold,
                'checkpoint_name': checkpoint_found
            }
            
        except Exception as e:
            self.log_message(f"解析模型文件夹失败: {e}")
            return None
            
    def get_matching_files(self, input_dir, mask_dir):
        """获取匹配的文件对"""
        input_files = [f for f in os.listdir(input_dir) if f.endswith('.nii.gz')]
        mask_files = [f for f in os.listdir(mask_dir) if f.endswith('.nii.gz')]
        
        def extract_numbers(filename):
            match = re.search(r'\d+', filename)
            return match.group() if match else ''
            
        input_map = {extract_numbers(f): f for f in input_files}
        mask_map = {extract_numbers(f): f for f in mask_files}
        
        matched_pairs = []
        for num_str in input_map:
            if num_str in mask_map:
                matched_pairs.append((input_map[num_str], mask_map[num_str]))
                
        unmatched_input = [f for f in input_files if extract_numbers(f) not in mask_map]
        unmatched_mask = [f for f in mask_files if extract_numbers(f) not in input_map]
        
        return matched_pairs, unmatched_input, unmatched_mask
        
    def process_mask2(self, input_dir, mask_raw_dir, mask_processed_dir):
        """处理mask2：膨胀0mm、HU阈值150，不裁剪"""
        dilation_mm = 0.0
        hu_threshold = 150
        crop_enabled = False
        
        matched_pairs, unmatched_input, unmatched_mask = self.get_matching_files(input_dir, mask_raw_dir)
        
        if unmatched_input:
            self.log_message(f"未找到匹配mask的输入文件 ({len(unmatched_input)}个)")
        if unmatched_mask:
            self.log_message(f"未找到匹配输入的mask文件 ({len(unmatched_mask)}个)")
            
        if not matched_pairs:
            raise ValueError("未找到任何匹配的输入图像和mask2文件")
            
        self.log_message(f"找到 {len(matched_pairs)} 对匹配文件，开始处理mask2")
        self.log_message(f"处理参数：膨胀尺寸={dilation_mm}mm, HU阈值={hu_threshold}, 裁剪={crop_enabled}")
        
        for input_file, mask_file in matched_pairs:
            try:
                self.log_message(f"处理 {input_file} (匹配mask: {mask_file})")
                input_path = os.path.join(input_dir, input_file)
                mask_path = os.path.join(mask_raw_dir, mask_file)
                output_path = os.path.join(mask_processed_dir, input_file)
                
                self.process_single_mask2(input_path, mask_path, output_path, dilation_mm, hu_threshold, crop_enabled)
                self.log_message(f"  处理成功: {output_path}")
            except Exception as e:
                self.log_message(f"  处理失败: {e}")
                raise
                
    def process_single_mask2(self, input_path, mask_path, output_path, dilation_mm, hu_threshold, crop_enabled):
        """处理单个mask2"""
        input_image = sitk.ReadImage(input_path)
        mask_image = sitk.ReadImage(mask_path)
        
        if input_image.GetSize() != mask_image.GetSize():
            raise ValueError(f"输入图像和mask大小不一致: {input_image.GetSize()} vs {mask_image.GetSize()}")
            
        # 处理mask
        mask_arr = sitk.GetArrayFromImage(mask_image)
        mask_arr = (mask_arr > 0).astype(np.uint8)
        original_mask = sitk.GetImageFromArray(mask_arr)
        original_mask.CopyInformation(mask_image)
        
        # 膨胀
        spacing = mask_image.GetSpacing()
        min_spacing = min(spacing)
        dilation_radius = max(1, int(np.ceil(dilation_mm / min_spacing)))
        
        dilate_filter = sitk.BinaryDilateImageFilter()
        dilate_filter.SetKernelRadius(dilation_radius)
        dilate_filter.SetKernelType(sitk.sitkBall)
        dilated_mask = dilate_filter.Execute(original_mask)
        
        # 不裁剪，使用完整图像
        cropped_input = input_image
        cropped_original_mask = original_mask
        cropped_dilated_mask = dilated_mask
        
        # 处理HU值
        img_arr = sitk.GetArrayFromImage(cropped_input).astype(np.int16)
        orig_mask_arr = sitk.GetArrayFromImage(cropped_original_mask)
        dilated_mask_arr = sitk.GetArrayFromImage(cropped_dilated_mask)
        
        output_arr = np.zeros_like(img_arr, dtype=np.int16)
        
        # 原始mask区域设为1000
        output_arr[orig_mask_arr == 1] = 1000
        
        # 膨胀区域
        expanded_region = (dilated_mask_arr == 1) & (orig_mask_arr == 0)
        high_ct_mask = expanded_region & (img_arr >= hu_threshold)
        low_ct_mask = expanded_region & (img_arr < hu_threshold)
        
        # 高CT值区域设为1000，低CT值区域设为0
        output_arr[high_ct_mask] = 1000
        output_arr[low_ct_mask] = 0
        
        # 保存结果
        output_image = sitk.GetImageFromArray(output_arr)
        output_image.CopyInformation(cropped_input)
        sitk.WriteImage(output_image, output_path)
        
    def map_labels(self, mask1_dir, mask3_dir, output_dir):
        """标签映射：整合mask1和mask3"""
        matched_pairs, unmatched_mask1, unmatched_mask3 = self.get_matching_files(mask1_dir, mask3_dir)
        
        if unmatched_mask1:
            self.log_message(f"未找到匹配mask3的mask1文件 ({len(unmatched_mask1)}个)")
        if unmatched_mask3:
            self.log_message(f"未找到匹配mask1的mask3文件 ({len(unmatched_mask3)}个)")
            
        if not matched_pairs:
            raise ValueError("未找到任何匹配的mask1和mask3文件")
            
        self.log_message(f"找到 {len(matched_pairs)} 对匹配文件，开始标签映射")
        
        for mask1_file, mask3_file in matched_pairs:
            try:
                self.log_message(f"处理 {mask1_file} 和 {mask3_file} 的标签映射")
                mask1_path = os.path.join(mask1_dir, mask1_file)
                mask3_path = os.path.join(mask3_dir, mask3_file)
                output_path = os.path.join(output_dir, mask1_file)
                
                # 读取mask1
                mask1_img = nib.load(mask1_path)
                mask1_data = mask1_img.get_fdata().astype(np.int16)
                
                # 读取mask3
                mask3_img = nib.load(mask3_path)
                mask3_data = mask3_img.get_fdata().astype(np.int16)
                
                # 检查尺寸是否一致
                if mask1_data.shape != mask3_data.shape:
                    self.log_message(f"  检测到尺寸不一致: mask1 {mask1_data.shape}, mask3 {mask3_data.shape}，尝试调整...")
                    mask3_data_resized = self.resize_mask(mask3_data, mask1_data.shape, mask3_img, mask1_img)
                    mask3_data = mask3_data_resized
                    
                # 创建结果数组
                result_data = np.zeros_like(mask1_data, dtype=np.int16)
                
                # 处理mask1标签映射
                self.log_message("  处理mask1标签映射...")
                for old_label, new_label in self.weight1_mapping.items():
                    mask1_regions = (mask1_data == old_label)
                    result_data[mask1_regions] = new_label
                    count = np.sum(mask1_regions)
                    if count > 0:
                        self.log_message(f"    mask1: 标签 {old_label} -> {new_label}, 包含 {count} 个体素")
                        
                # 处理mask3标签映射
                self.log_message("  处理mask3标签映射...")
                for old_label, new_label in self.weight3_mapping.items():
                    # 只在result_data为0的区域应用mask3标签
                    mask3_regions = (mask3_data == old_label) & (result_data == 0)
                    result_data[mask3_regions] = new_label
                    count = np.sum(mask3_data == old_label)
                    overlap_count = count - np.sum(mask3_regions)
                    if count > 0:
                        self.log_message(f"    mask3: 标签 {old_label} -> {new_label}, 包含 {count} 个体素, 与mask1重叠 {overlap_count} 个体素")
                        
                # 检查重叠
                total_overlap = np.sum((mask1_data > 0) & (mask3_data > 0))
                if total_overlap > 0:
                    self.log_message(f"  警告: 检测到 {total_overlap} 个体素的标签重叠区域，已保留mask1的标签")
                    
                # 保存结果
                result_img = nib.Nifti1Image(result_data, mask1_img.affine, mask1_img.header)
                nib.save(result_img, output_path)
                self.log_message(f"  标签映射完成: {output_path}")
                
            except Exception as e:
                self.log_message(f"  处理失败: {e}")
                raise
                
    def resize_mask(self, mask_data, target_shape, original_img, target_img):
        """调整mask尺寸到目标形状"""
        mask_img = sitk.GetImageFromArray(mask_data)
        mask_img.SetSpacing(original_img.header.get_zooms())
        mask_img.SetOrigin(original_img.affine[:3, 3])
        mask_img.SetDirection(original_img.affine[:3, :3].flatten())
        
        reference_img = sitk.GetImageFromArray(np.zeros(target_shape, dtype=np.int16))
        reference_img.SetSpacing(target_img.header.get_zooms())
        reference_img.SetOrigin(target_img.affine[:3, 3])
        reference_img.SetDirection(target_img.affine[:3, :3].flatten())
        
        resampler = sitk.ResampleImageFilter()
        resampler.SetReferenceImage(reference_img)
        resampler.SetTransform(sitk.Transform())
        resampler.SetInterpolator(sitk.sitkNearestNeighbor)
        resampler.SetDefaultPixelValue(0)
        
        resampled_mask = resampler.Execute(mask_img)
        return sitk.GetArrayFromImage(resampled_mask).astype(np.int16)
        
    def run_single_model_inference(self, model_info, input_dir, output_dir):
        """运行单个模型的推理"""
        try:
            cmd = [
                "nnUNetv2_predict",
                "-i", input_dir, "-o", output_dir,
                "-d", model_info['dataset_id'],
                "-c", model_info['config'],
                "-chk", model_info['checkpoint_name']
            ]
            cmd.extend(["-f", model_info['fold']])
            
            results_folder = os.path.dirname(os.path.dirname(model_info['path']))
            self.log_message(f"设置RESULTS_FOLDER: {results_folder}")
            
            env = os.environ.copy()
            env['nnUNet_results'] = results_folder
            env['PYTHONUNBUFFERED'] = '1'
            
            self.log_message(f"运行命令: {' '.join(cmd)}")
            result = subprocess.run(cmd, env=env, capture_output=True, text=True, check=True)
            self.log_message(f"命令执行成功: {model_info['dataset_id']}")
            
        except subprocess.CalledProcessError as e:
            self.log_message(f"推理失败: {e}")
            self.log_message(f"错误输出: {e.stderr}")
            raise
            
    def run_pipeline(self, cleanup_intermediate=False):
        """
        执行完整的nnUNet推理和标签映射流程
        cleanup_intermediate: 是否清理中间文件
        """
        self.log_message("=== 开始步骤2：nnUNet推理与标签映射 ===")
        
        # 检查输入文件
        nii_files = [f for f in os.listdir(self.input_folder) if f.endswith('.nii.gz')]
        if not nii_files:
            raise ValueError("输入文件夹中没有找到.nii.gz文件")
            
        # 检查temp文件夹完整性
        mask1_dir = os.path.join(self.temp_dir, "mask1")
        mask2_raw_dir = os.path.join(self.temp_dir, "mask2_raw")
        mask2_processed_dir = os.path.join(self.temp_dir, "mask2_processed")
        mask3_dir = os.path.join(self.temp_dir, "mask3")
        
        # 创建临时目录
        for dir_path in [mask1_dir, mask2_raw_dir, mask2_processed_dir, mask3_dir]:
            os.makedirs(dir_path, exist_ok=True)
            self.log_message(f"创建临时目录: {dir_path}")
            
        # 解析模型路径
        if len(self.model_paths) != 3:
            raise ValueError("必须提供三个模型路径")
            
        model_infos = []
        for i, path in enumerate(self.model_paths):
            info = self.parse_model_folder_path(path)
            if not info:
                raise ValueError(f"模型路径 {path} 解析失败")
            info['model_type'] = f'weight{i+1}'
            model_infos.append(info)
            
        # 权重1推理
        self.log_message("=== 开始权重1推理（生成10标签mask1）===")
        self.run_single_model_inference(model_infos[0], self.input_folder, mask1_dir)
        
        # 权重2推理
        self.log_message("=== 开始权重2推理（生成原始mask2）===")
        self.run_single_model_inference(model_infos[1], self.input_folder, mask2_raw_dir)
        
        # 处理mask2
        self.log_message("=== 开始处理mask2（膨胀0mm、HU阈值150，不裁剪）===")
        self.process_mask2(self.input_folder, mask2_raw_dir, mask2_processed_dir)
        
        # 权重3推理
        self.log_message("=== 开始权重3推理（输入处理后mask2，生成8标签mask3）===")
        self.run_single_model_inference(model_infos[2], mask2_processed_dir, mask3_dir)
        
        # 标签映射
        self.log_message("=== 开始整合mask1和mask3，执行标签映射 ===")
        self.map_labels(mask1_dir, mask3_dir, self.output_folder)
        
        # 清理中间文件
        if cleanup_intermediate:
            self.log_message("=== 清理中间文件 ===")
            try:
                if os.path.exists(self.temp_dir):
                    shutil.rmtree(self.temp_dir)
                    self.log_message(f"临时文件夹已清理: {self.temp_dir}")
            except Exception as e:
                self.log_message(f"清理临时文件夹失败: {str(e)}")
                
        self.log_message("✅ 步骤2：所有流程完成！最终结果已保存至输出文件夹")
        return True

def run_step2(input_folder, output_folder, model_paths, temp_dir=None, cleanup_intermediate=False):
    """
    执行步骤2的完整流程
    cleanup_intermediate: 是否清理中间文件
    """
    pipeline = NnUNetInferencePipeline(input_folder, output_folder, model_paths, temp_dir)
    return pipeline.run_pipeline(cleanup_intermediate)